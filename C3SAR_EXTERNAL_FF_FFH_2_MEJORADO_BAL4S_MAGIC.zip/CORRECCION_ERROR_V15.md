# EXTERNAL V1 V15 — corrección de compilación

Se corrigió el error de Swift en `SettingsView.swift` línea 155:

`initializer for conditional binding must have Optional type, not 'UIImage'`

La función Objective-C `iconForBundleID` está declarada como no opcional por `NS_ASSUME_NONNULL`, por eso se asigna directamente el resultado a `installedAppIcon` en lugar de usar `if let`.
